<html>
    <head>
        <title>Thank You</title>
    </head>
    
    <?php

if($_POST["submit"]) {
    $recipient="fbachani@gmail.com";
    $subject="Clipping Path Contact Form";
    $fullname=$_POST["fullname"];
    $email=$_POST["email"];
    $message=$_POST["message"];

    $mailBody="Name: $fullname\nEmail: $email\n\n$message";

    mail($recipient, $subject, $mailBody, "From: $fullname <$email>") or die("Didn't go any more.");

    echo $thankYou="<h2><p style='font-size: 45px; font-weight: 300; margin-top: 40px;' align='center'>Thank you! Your message has been sent.</p></h2>";   
    
} 

?>
    
</html>

