<?php 
// Pear library includes
// You should have the pear lib installed
include_once('Mail.php');
include_once('Mail_Mime/mime.php');

//Settings 
$max_allowed_file_size = 10000; // size in KB 
$allowed_extensions = array("jpg", "jpeg", "gif", "bmp");
$upload_folder = './uploads/'; //<-- this folder must be writeable by the script
$your_email = 'fbachani@gmail.com';//<<--  update this to your email address

$errors ='';

if(isset($_POST['submit']))
{
	//Get the uploaded file information
	$name_of_uploaded_file =  basename($_FILES['uploaded_file']['name']);
	
	//get the file extension of the file
	$type_of_uploaded_file = substr($name_of_uploaded_file, 
							strrpos($name_of_uploaded_file, '.') + 1);
	
	$size_of_uploaded_file = $_FILES["uploaded_file"]["size"]/1024;
	
	///------------Do Validations-------------
	if(empty($_POST['name'])||empty($_POST['email']))
	{
		$errors .= "\n Name and Email are required fields. ";	
	}
	if(IsInjected($visitor_email))
	{
		$errors .= "\n Bad email value!";
	}
	
	if($size_of_uploaded_file > $max_allowed_file_size ) 
	{
		$errors .= "\n Size of file should be less than $max_allowed_file_size";
	}
	
	//------ Validate the file extension -----
	$allowed_ext = false;
	for($i=0; $i<sizeof($allowed_extensions); $i++) 
	{ 
		if(strcasecmp($allowed_extensions[$i],$type_of_uploaded_file) == 0)
		{
			$allowed_ext = true;		
		}
	}
	
	if(!$allowed_ext)
	{
		$errors .= "\n The uploaded file is not supported file type. ".
		" Only the following file types are supported: ".implode(',',$allowed_extensions);
	}
	
	//send the email 
	if(empty($errors))
	{
		//copy the temp. uploaded file to uploads folder
		$path_of_uploaded_file = $upload_folder . $name_of_uploaded_file;
		$tmp_path = $_FILES["uploaded_file"]["tmp_name"];
		
		if(is_uploaded_file($tmp_path))
		{
		    if(!copy($tmp_path,$path_of_uploaded_file))
		    {
		    	$errors .= '\n error while copying the uploaded file';
		    }
		}
		
		//send the email
		$name = $_POST['name'];
		$visitor_email = $_POST['email'];
		$user_message = $_POST['message'];
		$to = $your_email;
		$subject="New form submission";
		$from = $your_email;
		$text = "A user  $name has sent you this message:\n $user_message";
		
		$message = new Mail_mime(); 
		$message->setTXTBody($text); 
		$message->addAttachment($path_of_uploaded_file);
		$body = $message->get();
		$extraheaders = array("From"=>$from, "Subject"=>$subject,"Reply-To"=>$visitor_email);
		$headers = $message->headers($extraheaders);
		$mail = Mail::factory("mail");
		$mail->send($to, $headers, $body);
		//redirect to 'thank-you page
		header('Location: thank-you.html');
	}
}
///////////////////////////Functions/////////////////
// Function to validate against any email injection attempts
function IsInjected($str)
{
  $injections = array('(\n+)',
              '(\r+)',
              '(\t+)',
              '(%0A+)',
              '(%0D+)',
              '(%08+)',
              '(%09+)'
              );
  $inject = join('|', $injections);
  $inject = "/$inject/i";
  if(preg_match($inject,$str))
    {
    return true;
  }
  else
    {
    return false;
  }
}
?>


<!DOCTYPE html> 
<html lang="en"> 
	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Sign Up | The Planet of Games</title>
        <meta name="keywords" content="clipping path, path, clipping, content writing, writing, content">
        <meta name="description" content="The is the official website of clipping path.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="Clipping Path">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>

    <style>

    .login {
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
        background-color: white;
        top: 0;
        position: absolute;
        height: 555px;
        width: 350px;
        right: ;
        border: 1px solid rgba(0,0,0,0.1);
        box-shadow: 0 1px 2px rgba(0,0,0,0.1);
    }  
        
    h2 {
        font-family: "Lato", sans-serif;
        margin-top: 40px;
        font-size: 30px;
    }
    
    .form-control {
        width: 300px;
        margin-top: 30px;
    }   
        
    body {
        background-color: #e7e7e7; 
        font-family: "lato", sans-serif;
    }    
    
    </style>

<body>
    
<div class="container">
    
    <div class="login">
        
        <h2 align="center">SIGNUP</h2>
        
        <div class="row" align="center">
            
            <?php
                if(!empty($errors))
                {
	               echo nl2br($errors);
                }
            ?>
            
            <form action="<?php echo htmlentities($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data" method="post" name="email_form_with_php">

            <p>
                <input type="text" name="name" class="form-control" placeholder="Your fullname . . ." required>
            </p>
            <p>
                <input type="text" name="email" class="form-control" placeholder="Your e-mail address . . ." required>
            </p>
            <p>
                <textarea name="message" class="form-control" rows="3" cols="3" placeholder="Your description . . ." required></textarea>
            </p>
            <p>
                <input type="file" name="uploaded_file" multiple style="margin-left: 70px; margin-top: 40px;">
            </p>
                <input class="btn btn-primary" type="submit" value="Sign Up" name='submit' style="margin-top: 30px;">
              
            </form>
            
            <script language="JavaScript">

                var frmvalidator  = new Validator("email_form_with_php");
                frmvalidator.addValidation("name","req","Please provide your name"); 
                frmvalidator.addValidation("email","req","Please provide your email"); 
                frmvalidator.addValidation("email","email","Please enter a valid email address"); 
                
            </script>
            
        </div>    
    
    </div>

</div>
      
</body>
    
</html>

