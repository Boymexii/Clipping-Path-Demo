<!DOCTYPE html> 
<html lang="en">

	<head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Clipping Path</title>
        <meta name="keywords" content="clipping path, clipping, path, writing, content writing">
        <meta name="description" content="This is the official website of Clipping Path Inc.">
        <meta name="author" content="Boymexii">
        <meta name="application-name" content="Clipping Path">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="all,follow">
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        
        <!-- font lato --->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400" rel="stylesheet">
        
        <link rel="stylesheet" type="text/css" href="style.css">

        <!-- font Awesome --->
        <script src="https://use.fontawesome.com/0ccc36992c.js"></script>
        
	</head>
    
    
    <body>
        
        <!--- Navbar --->
        <nav class="navbar navbar-default navbar-fixed-top topnav" role="navigation" style="background-color: white; box-shadow: 0 1px 2px rgba(0,0,0,0.1);">
            <div class="container topnav">

                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand topnav" href="index.php" style="color: black;">CLIPPING PATH</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="faq.html" style="color: #239d60; font-size: 18px;">FAQ</a>
                        </li>
                        <li>
                            <a href="#" style="color: #239d60; font-size: 18px;">Contact us</a>
                        </li>
                        <li>
                            <button class="btn btn-success" style="margin-top: 9px; background-color: #239d60;"><a href="users/signup.php" style="color: white;">Sign Up</a></button>
                        </li>
                    </ul>
                </div>

            </div>

        </nav>

        
        <!--- Slider ---->
        <slider>
        
        </slider>
        
        
        <!--- Clipping Path --->
        <div class="container-fluid" style="margin-top: 55px;">
            <center><h2 style="font-weight: 300; font-size: 40px; margin-top: 50px;">Clipping Path</h2></center>
        </div>
    
        <div class="container" style="margin-bottom: 40px;">
        <div class="row" align="center">
            <form style="margin-top: 35px; width: 600px;">
                <input class="form-control" placeholder="Upload your file...">
                <a href="users/signup.php"><input class="btn btn-default" style="margin-top: 25px; background-color: #239d60; color: white;" type="button" value="Upload now"></a>
            </form>
        </div>
        </div>
        
        
        <!--- Heading page --->
        <h2 align="center">Welcome!</h2>
        <p align="center" style="margin-top: -10px;">
        <i style="font-size: 16px; font-weight: 300; color: #94d8f4;">Try 3 clippings for free-- You have nothing to lose and 3 to gain</i>
        </p>
        <div class="container" style="margin-bottom: 32px;">
            <div class="row" style="font-size: 16px; font-weight: 300;">
                <div class="col-lg-4">
                    <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Starting as Low is 15&cent;</p>
                </div>
                <div class="col-lg-4">
                    <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Round the clock Support</p>
                </div>
                <div class="col-lg-4">
                    <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Quick as a bee (24Hrs. Standard, 12 Hrs. Quick delivery)</p>
                </div>
                <div class="col-lg-4">
                    <p><i class="fa fa-check-square-o" aria-hidden="true"></i> No Hassle, Smooth as silk</p>
                </div>
                <div class="col-lg-4">
                    <p><i class="fa fa-check-square-o" aria-hidden="true"></i> Online Editing-- No software download required</p>
                </div>
            </div>
        </div>

        
        <!--- Free trial ---->
        <h2 align="center">Free Trial</h2>
        <p align="center" style="font-weight: 300; font-size: 18px;">
            Get 3 edits absolutely free. We deliver all the free edits without any compromise on the quality and exactly as<br> you like them. Please give the specifications of the desired file(dimensions, file size, special features).<br> The delivery time is same as the paid trials and any post-retouch reviews and adjustments are on the house too.
        </p>
        <p align="center" style="margin-bottom: 32px; font-weight: 300; font-size: 21px;">
            Try for free Now--All the perks and ZERO cuts.
        </p>
        
        <!--- How it works section ---->
        <h2 align="center">How it works</h2>
        <p align="center" style="margin-top: -10px; font-weight: 300; font-size: 16px;">Our method is very user-friendly. You can never get lost. Just follow these baby steps to get your clippings.</p>
        
        <div class="container">
            
        <div class="row" style="margin-top: 38px;" align="center">
            
            <div class="col-lg-4">
                <img src="images/uploadimage.png" style="width: 100px; height: 100px;">
                <p style="margin-top: 10px; font-size: 15px;">Upload your images and wait for our response</p>
                <p align="left" style="font-size: 15px; font-weight: 300;"><b>Tip:</b> You can upload as many pictures as you like. We do not have any maximum image cap. Just upload the files and wait for our representative to get back to you.</p>
            </div>
            <div class="col-lg-4">
                <img src="images/invoice.png" style="width: 100px; height: 100px;">
                <p style="margin-top: 10px; font-size: 15px;">Get your invoice</p>
                <p align="left" style="font-size: 15px; font-weight: 300;"><b>Tip:</b> Our Real Live representation will get back to you within 5 minutes with the total cost depending on the complexity and amount of the work.</p>
            </div>
            <div class="col-lg-4">
                <img src="images/clippings.png" style="width: 100px; height: 100px;">
                <p style="margin-top: 10px; font-size: 15px;">Get your clippings</p>
                <p align="left" style="font-size: 15px; font-weight: 300;"><b>Tip:</b> Download your clippings in 24Hrs. Guaranteed! Or choose the 12Hrs. Quick Service. We e-mail you the clippings as the e-mail address you provide.</p>
            </div>
            
        </div>
            
        </div>
        
        <!---- Why us section ---->
        <h2 align="center" style="margin-top: 36px;">Why Us?</h2>
        
        <p align="center" style="font-size: 15px; font-weight: 300;">
            <b>1.</b> Your ease is our comfort, Online process. You just need to upload images<br>
            <b>2.</b> You save a lot of money: Starting price is <b>15&cent;</b> per image.<br>
            <b>3.</b> You save a lot of time: Guaranteed delivery in 24hours (12 hours Quick delivery option)<br>
            <b>4.</b> Our 10 years of experience makes the best in the business.<br>
            <b>5.</b> We don't compromise on quality. Our work comes 100% money back guarantee, <br>if you are not satisfied with the quality of clippings. We deliver only after a rigorous Quality Control Check.<br>
            <b>6.</b> Your individuality is your speciality. Every client is special to us.
        </p>
        
        <!--- Our Service section ---->
        <h2 align="center" style="margin-top: 36px; margin-bottom: 32px;">Our Services</h2>
        
        
        <!-- Contact Us ---->
        <div class="contactus" style="background-color: #eef3f2; border: 1px solid rgba(0,0,0,0.1); box-shadow: 0 1px 2px rgba(0,0,0,0.1);"><br>
        <h2 align="center">Contact Us</h2>
        <p align="center" style="font-weight: 300; font-size: 16px;">Feel free to contact us anytime by clicking the details given below or fill out our customer care form.<br>Our representative will immediately get in touch with you.</p>
        
        <div class="container">
        <div class="row" align="center">
        <form style="width: 400px;" action="contactform/sentemail.php" method="post">
            <input class="form-control" name="fullname" type="text" placeholder="Your fullname . . ." required><br>
            <input class="form-control" name="email" type="text" placeholder="Your e-mail address . . ." required><br>
            <textarea class="form-control" name="message" cols="3" rows="7" placeholder="Your message . . ." required></textarea><br>
            <input class="btn btn-default" type="submit" value="Send Now" name="submit" required>
        </form>
        </div>
        </div><br><br>
        </div>
        
        <!---- footer ---->
        <div class="footer" style="margin-bottom: 30px; margin-top: 30px; font-weight: 300;">
            <h3 align="center" style="color: #999; font-weight: 300;">CLIPPING PATH</h3>
            <p align="center" style="font-size: 14px; color: #999;">Made in Pakistan · Copyright 2016 · All rights reserved</p>
        </div>
        
        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        
        <script src="index.js"></script>
        
    </body>
    
</html>
